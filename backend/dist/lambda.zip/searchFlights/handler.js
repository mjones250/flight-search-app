"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const flights = [
    {
        flightId: 'NJ501',
        aircraftType: 'Citation XLS',
        from: 'CMH',
        to: 'TEB',
        departureTime: '2026-02-01T09:00:00Z',
        arrivalTime: '2026-02-01T11:00:00Z'
    },
    {
        flightId: 'NJ742',
        aircraftType: 'Phenom 300',
        from: 'CMH',
        to: 'FXE',
        departureTime: '2026-02-01T13:00:00Z',
        arrivalTime: '2026-02-01T15:30:00Z'
    },
    {
        flightId: 'NJ310',
        aircraftType: 'Challenger 350',
        from: 'TEB',
        to: 'CMH',
        departureTime: '2026-02-01T17:00:00Z',
        arrivalTime: '2026-02-01T19:00:00Z'
    }
];
const jsonResponse = (statusCode, body) => ({
    statusCode,
    headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify(body)
});
const handler = async (event) => {
    try {
        const from = event.queryStringParameters?.from;
        const to = event.queryStringParameters?.to;
        const date = event.queryStringParameters?.date;
        if (!from || !to || !date) {
            return jsonResponse(400, {
                error: 'Missing required query parameters: from, to, date'
            });
        }
        const normalizedFrom = from.toUpperCase();
        const normalizedTo = to.toUpperCase();
        const results = flights.filter((f) => f.from === normalizedFrom &&
            f.to === normalizedTo &&
            f.departureTime.startsWith(date));
        return jsonResponse(200, results);
    }
    catch (err) {
        // logging removed to avoid needing the 'console' global; add @types/node or adjust tsconfig lib if you want console usage
        return jsonResponse(500, { error: 'Internal server error' });
    }
};
exports.handler = handler;
